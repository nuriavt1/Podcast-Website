
function Searcher(){
<section>
<form onSubmit={handleSearchSubmit}>
<input type="text" value={search} onChange={handleSearchChange} placeholder="Search podcasts..." />
<button type="submit">Filter</button>
</form>
</section>
}

# Podcast-Website
We are going to use the Spotify API we’ll focus out platform in podcasts
